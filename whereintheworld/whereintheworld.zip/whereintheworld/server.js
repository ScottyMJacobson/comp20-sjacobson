//Initialize Express
var express = require('express');
var path = require('path');
var bodyParser = require('body-parser');
var async = require('async');

//Mongo Configuration with MongoLab
var mongoUri = process.env.MONGOLAB_URI || process.env.MONGOHQ_URL || 'mongodb://localhost/whereintheworld';
var mongo = require('mongodb');
var db, locations_collection;

async.series([setupDB, launchServer]);

function setupDB (callback) {
    db = mongo.Db.connect(mongoUri, function (error, databaseConnection) 
                                {
                                    if (error) {
                                        throw error;
                                    }
                                    else {
                                        db = databaseConnection;
                                        locations_collection = db.collection('locations');
                                        callback();
                                    }
                                }
                            );
}

function launchServer(callback) {

    //Main configuration
    var app = express();

    //Set jade as the view engine
    app.set('vews', __dirname + '/views');
    app.set('view engine', 'jade');
    app.set('view options', {layout: false});

    //Serve static pages from the "public" folder
    app.use(express.static(path.join(__dirname, 'public')));

    //Use body-parser with json or url-encoded queries
    app.use( bodyParser.json() );       // to support JSON-encoded bodies
    app.use( bodyParser.urlencoded({ extended: true }) ); // support URL-encoded

    // Routes broken out to separate file to keep server.js uncluttered
    require('./routes')(app, locations_collection);

    //Set up app to listen on port 3000
    app.listen(process.env.PORT || 3000);

}
