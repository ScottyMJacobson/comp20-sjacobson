whereintheworld
================
Using Heroku, Node.js with the Express web framework, and MongoDB, 
whereintheworld is a web application that maintains "location check-ins" 
(login, latitude, and longitude) for a long period of time.