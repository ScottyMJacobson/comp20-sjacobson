whereintheworld
===============
######COMP20 Assignment 4



###Implemented:
I believe I have correctly implemented all endpoints. WhereInTheWorld is deployed on heroku at [scottyjwhereintheworld.herokuapp.com](scottyjwhereintheworld.herokuapp.com).

###Collaborated:
I did not collaborate with anyone for my project.

###Time Spent:
I've probably spent 20 hours on the project.

