var async = require('async');

//Configuration for geocoding reverse lookup:
var geocoderProvider = 'google';
var httpAdapter = 'http';
var geocoder = require('node-geocoder').getGeocoder(geocoderProvider, httpAdapter, {});

module.exports = {
    
    validate: function (dataToValidate) {

        var dataIsValid = true;
        dataIsValid = dataIsValid && (typeof(dataToValidate['login']) != "undefined");
        dataIsValid = dataIsValid && (typeof(dataToValidate['lat']) != "undefined");
        dataIsValid = dataIsValid && (typeof(dataToValidate['long']) != "undefined");

        return (dataIsValid);
    },
    
    getLastHundredEntries: function (locationsCollection, callback) {
        var queryCursor = locationsCollection.find({}).sort({created_at:-1}).limit(100).toArray(
                function(err, results) {
                    if (err) {
                        console.log("Error with sort and find query!");
                    }
                    else {
                        callback(results);
                    }
                }
            );
    },

    insertNewEntry: function (locationsCollection, validatedRequestBody, callback) {
        requestBody['created_at'] = new Date();
            locationsCollection.insert(
                requestBody, 
                function(err, docs) {
                    if (err) {
                        console.log("error in inserting recent entry");
                    }   
                    else {                     
                        module.exports.getLastHundredEntries(locationsCollection, callback);
                    }
                }
            );
    },


    getEntriesForUser: function (locationsCollection, userName, callback) {
        var queryObject = {login: userName};
        var queryCursor = locationsCollection.find(queryObject).sort({created_at:-1}).toArray(
                function(err, results) {
                    if (err) {
                        console.log("Error with finding user query!");
                    }
                    else {
                        callback(results);
                    }
                }
            );
    },

    getAllEntriesAndRevGeocode: function (locationsCollection, callback) {
        var queryObject = {};
        var queryCursor = locationsCollection.find(queryObject).sort({created_at:-1}).toArray(
                function(err, results) {
                    if (err) {
                        console.log("Error with finding user query!");
                        throw err;
                    }
                    else {
                        module.exports.populateReverseLocations(results, callback);
                    }
                }
            );
    },

    populateReverseLocations: function (completeLocationsList, callback) {
            async.map(completeLocationsList, module.exports.replaceCoordinatesWithRevGeocode, 
                function (err, revLocationsList) {
                                            if (err) {
                                                throw err;
                                            }
                                            else {
                                                callback(revLocationsList);
                                            }
                                        }); 
    },

    replaceCoordinatesWithRevGeocode: function (tempLocation, callback) {
        geocoder.reverse(tempLocation['lat'], tempLocation['long'], 
                                function (callback, tempLocation) 
                                {       
                                    return function (err, revLookupResult) {
                                        if (err) {
                                            throw err;
                                        }
                                        revLookupResult = revLookupResult[0];
                                        addressString = revLookupResult['streetName'] + ', ' 
                                                        + revLookupResult['city'] + ', ' 
                                                        + revLookupResult['state'] + ', ' 
                                                        + revLookupResult['countryCode'];
                                        compiledLocation = {
                                            login: tempLocation['login'],
                                            address: addressString,
                                            created_at: tempLocation['created_at']
                                        };
                                        callback(err, compiledLocation);
                                    }; 
                                } (callback, tempLocation));
    }

};

