var WhereInTheWorld = require("./whereintheworld.js");
var unirest = require("unirest");

module.exports = function (app, locationsCollection) {

    app.get('/', function(req, res) {

        function renderIndexWithLocations (finalLocationsList) {
            res.render('index', {locations : finalLocationsList} ); 
        };

        WhereInTheWorld.getAllEntriesAndRevGeocode(locationsCollection, renderIndexWithLocations);
 
    });


    app.post('/sendlocation', function(req, res) {

        requestBody = req.body;

        function respondToSendLocation (recent100Entries) {
            var response_object = {
                characters: [],
                students: recent100Entries 
                };            
            res.json(response_object);
        }

        if (WhereInTheWorld.validate(requestBody)) {
            WhereInTheWorld.insertNewEntry(locationsCollection, requestBody, respondToSendLocation);
        }
        else {
            WhereInTheWorld.getLastHundredEntries(locationsCollection, respondToSendLocation);
        }
    });


    app.get('/locations.json', function(req, res) {
 
        function sendBackResults (results) {
            res.json(results);
        }

        if (req['query']['user']) {
            WhereInTheWorld.getEntriesForUser(locationsCollection, req['query']['user'], sendBackResults);
        }

        else {
            res.json([]);
        }

    })


    app.get('/redline.json', function(req, res) {

        function sendBackResults (results) {
            res.json(results['body']);
        }

        var redlineURI = 'http://developer.mbta.com/lib/rthr/red.json';

        unirest.get(redlineURI, {}, {}, sendBackResults);
    })

};